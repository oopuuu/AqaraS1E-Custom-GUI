#!/bin/sh
TRIGGER_REASON="$1"
TS=$(date "+%Y-%m-%d %H:%M:%S" 2>/dev/null || echo "Unknown")

# Check flash log write permission (Default: 0 / Disabled -> write to /tmp RAM disk)
INC_DIR="/tmp"
if [ -f /tmp/flash_log_enabled ]; then
    INC_DIR="/data/scripts"
elif grep -q '"flash_log_enabled": *1' /data/scripts/sys_settings.json 2>/dev/null; then
    INC_DIR="/data/scripts"
fi
INC_F="$INC_DIR/crash_incident.log"

# Auto-rotate if larger than 128KB
if [ -f "$INC_F" ]; then
    SZ=$(wc -c < "$INC_F" 2>/dev/null || echo 0)
    if [ "$SZ" -gt 131072 ]; then
        mv -f "$INC_F" "${INC_F}.1" 2>/dev/null
    fi
fi

echo "================================================================" >> "$INC_F"
echo "[10-DIMENSION INCIDENT DUMP] $TS | Trigger: $TRIGGER_REASON" >> "$INC_F"
echo "Uptime & Load: $(uptime 2>/dev/null)" >> "$INC_F"
echo "Memory Available: $(awk '/MemAvailable:/ {print int($2/1024)"MB ("$2" KB)"}' /proc/meminfo 2>/dev/null)" >> "$INC_F"
echo "----------------------------------------------------------------" >> "$INC_F"
echo "[1. Real-Time Process Top (Instantaneous CPU% & Memory%)]" >> "$INC_F"
top -b -n 1 2>/dev/null | head -n 22 >> "$INC_F"
echo "----------------------------------------------------------------" >> "$INC_F"
echo "[2. Multi-Thread & Kernel Stack Deep Forensics]" >> "$INC_F"
for PN in s1e_standalone_app ha_daemon httpd ubusd ha_driven ha_master; do
    PID=$(pidof "$PN" 2>/dev/null | awk '{print $1}')
    if [ -n "$PID" ]; then
        WC=$(cat /proc/$PID/wchan 2>/dev/null || echo "?")
        FD=$(ls /proc/$PID/fd 2>/dev/null | wc -w)
        RSS=$(awk '/VmRSS:/ {print $2" "$3}' /proc/$PID/status 2>/dev/null || echo "?")
        VSZ=$(awk '/VmSize:/ {print $2" "$3}' /proc/$PID/status 2>/dev/null || echo "?")
        echo "Process: $PN (PID: $PID) | RSS: $RSS | VSZ: $VSZ | Wchan: $WC | Open FDs: $FD" >> "$INC_F"
        # Thread-level inspection
        if [ -d "/proc/$PID/task" ]; then
            for TID in $(ls /proc/$PID/task 2>/dev/null); do
                if [ "$TID" != "$PID" ]; then
                    TNAME=$(cat /proc/$PID/task/$TID/comm 2>/dev/null)
                    TWC=$(cat /proc/$PID/task/$TID/wchan 2>/dev/null)
                    echo "  -> Thread TID $TID ($TNAME): wchan=$TWC" >> "$INC_F"
                fi
            done
        fi
        if [ -f "/proc/$PID/stack" ]; then
            STK=$(head -n 4 /proc/$PID/stack 2>/dev/null | awk '{printf "%s | ", $0}')
            echo "  Kernel Stack: $STK" >> "$INC_F"
        fi
    fi
done
echo "----------------------------------------------------------------" >> "$INC_F"
echo "[3. Wireless Physical Signal, Link & Interface Errors]" >> "$INC_F"
timeout -t 2 wpa_cli -i wlan0 status 2>/dev/null | grep -E 'wpa_state|ssid|bssid|ip_address|pairwise_cipher' >> "$INC_F"
timeout -t 2 wpa_cli -i wlan0 signal_poll 2>/dev/null | grep -E 'RSSI|LINKSPEED|NOISE|FREQUENCY' >> "$INC_F"
awk '/wlan0:/ {printf "wlan0 I/O: RX pkts=%s err=%s drop=%s | TX pkts=%s err=%s drop=%s\n", $3, $4, $5, $11, $12, $13}' /proc/net/dev 2>/dev/null >> "$INC_F"
echo "----------------------------------------------------------------" >> "$INC_F"
echo "[4. Active Sockets & Connection Queue Depths]" >> "$INC_F"
netstat -ntu 2>/dev/null >> "$INC_F"
cat /proc/net/sockstat 2>/dev/null >> "$INC_F"
echo "----------------------------------------------------------------" >> "$INC_F"
echo "[5. Memory Subsystems & VM Paging Activity]" >> "$INC_F"
awk '/MemTotal|MemFree|MemAvailable|Buffers|Cached|Slab|SReclaimable|SUnreclaim|PageTables|Mapped|AnonPages|Shmem|VmallocUsed/ {printf "%-16s %s %s\n", $1, $2, $3}' /proc/meminfo 2>/dev/null >> "$INC_F"
grep -E 'allocstall|oom_kill|compact_fail|pgfree' /proc/vmstat 2>/dev/null | awk '{printf "%-16s %s\n", $1, $2}' >> "$INC_F"
echo "----------------------------------------------------------------" >> "$INC_F"
echo "[6. Storage & Flash Space (UBIFS & Tmpfs)]" >> "$INC_F"
df -h /data /tmp /misc 2>/dev/null >> "$INC_F"
echo "----------------------------------------------------------------" >> "$INC_F"
echo "[7. CPU Context Switches, I/O Blocked & Interrupts]" >> "$INC_F"
grep -E 'ctxt|procs_running|procs_blocked' /proc/stat 2>/dev/null >> "$INC_F"
grep -E 'wlan|wifi|disp|timer|gpi|mmc' /proc/interrupts 2>/dev/null >> "$INC_F"
echo "----------------------------------------------------------------" >> "$INC_F"
echo "[8. Kernel Ring Buffer (dmesg last 40 entries)]" >> "$INC_F"
dmesg 2>/dev/null | tail -n 40 >> "$INC_F"
echo "================================================================" >> "$INC_F"
sync
