#!/bin/sh
export PATH=/bin:/sbin:/usr/bin:/usr/sbin:$PATH
export TZ=CST-8
echo "CST-8" > /etc/TZ 2>/dev/null

# 0. Sync Flash Log Toggle State from persistent sys_settings.json (Default: 0 / RAM-only)
if grep -q '"flash_log_enabled": *1' /data/scripts/sys_settings.json 2>/dev/null; then
    touch /tmp/flash_log_enabled 2>/dev/null
else
    rm -f /tmp/flash_log_enabled 2>/dev/null
fi

# 1. 100% Guaranteed Instant Root Shell & Password on Port 23
echo "root:qdGt8T0XjiWXI:0:0:root:/home/root:/bin/sh" > /tmp/passwd
echo "root:qdGt8T0XjiWXI:18800:0:99999:7:::" > /tmp/shadow
chmod 644 /tmp/passwd /tmp/shadow
mount --bind /tmp/passwd /etc/passwd 2>/dev/null
mount --bind /tmp/shadow /etc/shadow 2>/dev/null
umount -l /misc 2>/dev/null
mount -t tmpfs tmpfs /misc 2>/dev/null
cp -f /tmp/passwd /misc/passwd 2>/dev/null
cp -f /tmp/shadow /misc/shadow 2>/dev/null
chmod 644 /misc/passwd /misc/shadow 2>/dev/null

if ! pidof telnetd >/dev/null 2>&1; then
    telnetd -p 23 -l /bin/sh &
fi

# 2. Instant Web Server Setup & Launch (Available in < 50ms)
mkdir -p /tmp/www/cgi-bin
cp -f /data/scripts/index.html /tmp/www/index.html 2>/dev/null
cp -f /data/scripts/api.cgi /tmp/www/cgi-bin/api.cgi 2>/dev/null
chmod +x /data/scripts/s1e_standalone_app \
         /data/scripts/ha_daemon \
         /data/scripts/api.cgi \
         /data/scripts/snap_fast \
         /data/scripts/http_body_strip \
         /data/scripts/safe_png_recv \
         /data/scripts/fetch_https.sh \
         /data/scripts/dump_incident.sh \
         /tmp/www/cgi-bin/api.cgi 2>/dev/null
chmod +x /data/scripts/*.sh 2>/dev/null

killall httpd 2>/dev/null
httpd -p 8080 -h /tmp/www

# 2.5 Core IPC & Hardware Relay Driver Stack (Mandatory for physical relay switching)
if ! pidof ubusd >/dev/null 2>&1; then
    ubusd </dev/null >/dev/null 2>&1 &
    sleep 0.2
fi
if ! pidof property_service >/dev/null 2>&1; then
    property_service -i /etc/build.prop -p /data/storage/prop.dat -b </dev/null >/dev/null 2>&1 &
    sleep 0.2
fi
if ! pidof ha_agent >/dev/null 2>&1; then
    ha_agent -D </dev/null >/dev/null 2>&1 &
    sleep 0.5
fi
if ! pidof ha_driven >/dev/null 2>&1; then
    ha_driven -O1 -L7 </dev/null >/dev/null 2>&1 &
    sleep 0.2
fi
if ! pidof ha_master >/dev/null 2>&1; then
    ha_master -H -S -a /lib/libha_auto.so </dev/null >/dev/null 2>&1 &
fi
if ! pidof ha_basis >/dev/null 2>&1; then
    ha_basis </dev/null >/dev/null 2>&1 &
fi
if ! pidof ha_lanbox >/dev/null 2>&1; then
    ha_lanbox </dev/null >/dev/null 2>&1 &
fi

# 3. Hardware Backlight & Standalone GUI Launch
if [ ! -d /sys/class/pwm/pwmchip0/pwm0 ]; then
    echo 0 > /sys/class/pwm/pwmchip0/export 2>/dev/null
fi
echo 200000 > /sys/class/pwm/pwmchip0/pwm0/period 2>/dev/null
echo 1 > /sys/class/pwm/pwmchip0/pwm0/enable 2>/dev/null
echo 200000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle 2>/dev/null

sed -i "s/option enable 'true'/option enable 'false'/" /data/app/config/setting 2>/dev/null
sed -i "s/option screenAlwaysOn 'false'/option screenAlwaysOn 'true'/" /data/app/config/setting 2>/dev/null

killall -9 aqgui gui_monitor.sh app_monitor.sh 2>/dev/null

if ! pidof s1e_standalone_app >/dev/null 2>&1; then
    nohup /data/scripts/s1e_standalone_app >/tmp/app.log 2>&1 &
fi

# 4. Asynchronous Wi-Fi & System Network Startup (Non-blocking Background)
UPTIME_SEC=$(awk '{print int($1)}' /proc/uptime 2>/dev/null || echo 0)
if [ "$UPTIME_SEC" -lt 60 ] && [ ! -f /tmp/post_init_done ]; then
    (
        fw_manager.sh -r >/tmp/post_init_fw.log 2>&1
        touch /tmp/post_init_done
        for i in $(seq 1 30); do
            if ping -c 1 223.5.5.5 >/dev/null 2>&1 || ping -c 1 119.29.29.29 >/dev/null 2>&1; then
                break
            fi
            sleep 1
        done
        /usr/sbin/ntpd -q -N -p ntp.aliyun.com -p time1.cloud.tencent.com -p cn.pool.ntp.org -p pool.ntp.org 2>/dev/null
        touch /tmp/layout_updated
        /usr/sbin/ntpd -N -p ntp.aliyun.com -p time1.cloud.tencent.com -p cn.pool.ntp.org -p pool.ntp.org 2>/dev/null
    ) &
else
    echo "[post_init] System already running (uptime: ${UPTIME_SEC}s). Skipping cold-boot hardware/network re-init." >/tmp/post_init_fw.log
fi

if [ -f /data/scripts/web_telnetd ] && ! pidof web_telnetd >/dev/null 2>&1; then
    chmod +x /data/scripts/web_telnetd 2>/dev/null
    nohup /data/scripts/web_telnetd >/tmp/web_telnetd.log 2>&1 &
fi
if ! pidof ha_daemon >/dev/null 2>&1; then
    nohup /data/scripts/ha_daemon >/tmp/ha_daemon.log 2>&1 &
fi

# Helper: Exhaustive 10-Dimension Crime Scene Forensics Engine (Pre-Freeze Auto-Dump)
dump_incident_snapshot() {
    if [ -x /data/scripts/dump_incident.sh ]; then
        /data/scripts/dump_incident.sh "$1"
    fi
}

WIFI_TICK=0
LOOP_CNT=11
while true; do
    sleep 5
    NOW=$(date +%s)

    # Check flash log write permission (Default: 0 / Disabled -> write to /tmp RAM disk)
    FLASH_LOG_DIR="/tmp"
    if [ -f /tmp/flash_log_enabled ]; then
        FLASH_LOG_DIR="/data/scripts"
    elif grep -q '"flash_log_enabled": *1' /data/scripts/sys_settings.json 2>/dev/null; then
        FLASH_LOG_DIR="/data/scripts"
        touch /tmp/flash_log_enabled 2>/dev/null
    fi

    # 0.0 Core IPC, Property Service, Web Server & Telnet Watchdog
    if ! pidof httpd >/dev/null 2>&1; then
        httpd -p 8080 -h /tmp/www
    fi
    if ! pidof telnetd >/dev/null 2>&1; then
        telnetd -p 23 -l /bin/sh &
    fi
    if ! pidof ubusd >/dev/null 2>&1; then
        ubusd </dev/null >/dev/null 2>&1 &
        sleep 0.2
    fi
    if ! pidof property_service >/dev/null 2>&1; then
        property_service -i /etc/build.prop -p /data/storage/prop.dat -b </dev/null >/dev/null 2>&1 &
        sleep 0.2
    fi
    if ! pidof ha_agent >/dev/null 2>&1; then
        ha_agent -D </dev/null >/dev/null 2>&1 &
        sleep 0.5
    fi
    if ! pidof ha_driven >/dev/null 2>&1; then
        ha_driven -O1 -L7 </dev/null >/dev/null 2>&1 &
        sleep 0.2
    fi
    if ! pidof ha_master >/dev/null 2>&1; then
        ha_master -H -S -a /lib/libha_auto.so </dev/null >/dev/null 2>&1 &
    fi
    if ! pidof ha_basis >/dev/null 2>&1; then
        ha_basis </dev/null >/dev/null 2>&1 &
    fi
    if ! pidof ha_lanbox >/dev/null 2>&1; then
        ha_lanbox </dev/null >/dev/null 2>&1 &
    fi

    # 0.05 RAM Pressure Auto-Relief (Reclaims clean cached pages if Available < 8MB)
    AVAIL_KB=$(awk '/MemAvailable/ {print $2}' /proc/meminfo 2>/dev/null || echo 10000)
    if [ -n "$AVAIL_KB" ] && [ "$AVAIL_KB" -lt 8192 ]; then
        echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
    fi

    # -------------------------------------------------------------
    # 1. High-Safety Multi-Layer Watchdogs with Strict Timeouts
    # -------------------------------------------------------------
    NOW_MONO=$(awk '{print int($1)}' /proc/uptime 2>/dev/null || echo 0)

    # 1.1 UI Process Heartbeat Watchdog & Pre-Freeze Dump
    APP_PID=$(pidof s1e_standalone_app 2>/dev/null)
    if [ -z "$APP_PID" ]; then
        nohup /data/scripts/s1e_standalone_app >/tmp/app.log 2>&1 &
        echo "$NOW_MONO" > /tmp/app_heartbeat
    else
        if [ -f /tmp/app_heartbeat ]; then
            LAST_HB=$(cat /tmp/app_heartbeat 2>/dev/null | tr -cd '0-9')
            if [ -n "$LAST_HB" ]; then
                DIFF=$((NOW_MONO - LAST_HB))
                # Pre-Freeze Forensics Dump (Stalled for > 15s)
                if [ "$DIFF" -ge 15 ] && [ ! -f /tmp/inc_hb_dumped ]; then
                    touch /tmp/inc_hb_dumped
                    dump_incident_snapshot "UI Heartbeat Stalled ($DIFF s, PID: $APP_PID)"
                fi
                # Stage 1: Soft restart process if stalled for 45s ~ 120s
                if [ "$DIFF" -ge 45 ] && [ "$DIFF" -lt 120 ]; then
                    DATE_STR=$(date "+%Y-%m-%d %H:%M:%S" 2>/dev/null || echo "Unknown")
                    echo "[WATCHDOG] Process stalled for $DIFF s (PID: $APP_PID) -> Soft restarting at $DATE_STR" >> "$FLASH_LOG_DIR/crash_watchdog.log"
                    killall -9 s1e_standalone_app 2>/dev/null
                    sleep 0.5
                    nohup /data/scripts/s1e_standalone_app >/tmp/app.log 2>&1 &
                    echo "$NOW_MONO" > /tmp/app_heartbeat
                # Stage 2: Hardware reboot if process failed to recover for > 120s
                elif [ "$DIFF" -ge 120 ]; then
                    DATE_STR=$(date "+%Y-%m-%d %H:%M:%S" 2>/dev/null || echo "Unknown")
                    echo "[WATCHDOG] Hard UI Freeze (>120s, PID: $APP_PID) -> Rebooting hardware at $DATE_STR" >> "$FLASH_LOG_DIR/crash_watchdog.log"
                    sync
                    sleep 1
                    reboot -f
                elif [ "$DIFF" -lt 10 ]; then
                    rm -f /tmp/inc_hb_dumped 2>/dev/null
                fi
            fi
        else
            echo "$NOW_MONO" > /tmp/app_heartbeat
        fi
    fi

    # 1.2 Network & Gateway Reachability Watchdog (Immune to Static IP false-positives)
    if [ "$NOW_MONO" -gt 60 ]; then
        GW_IP=$(ip route 2>/dev/null | awk '/default/ {print $3}' | head -n1)
        NET_ALIVE=0
        if [ -n "$GW_IP" ]; then
            if timeout -t 2 ping -c 1 "$GW_IP" >/dev/null 2>&1; then
                NET_ALIVE=1
            fi
        fi
        if [ "$NET_ALIVE" -eq 0 ]; then
            if timeout -t 2 ping -c 1 223.5.5.5 >/dev/null 2>&1 || timeout -t 2 ping -c 1 119.29.29.29 >/dev/null 2>&1; then
                NET_ALIVE=1
            fi
        fi

        if [ "$NET_ALIVE" -eq 1 ]; then
            WIFI_FAIL_CNT=0
            rm -f /tmp/inc_wifi_dumped 2>/dev/null
        else
            WIFI_FAIL_CNT=$(( ${WIFI_FAIL_CNT:-0} + 1 ))
            # Pre-Freeze Incident Dump (Network unreachable for 15s)
            if [ "$WIFI_FAIL_CNT" -ge 3 ] && [ ! -f /tmp/inc_wifi_dumped ]; then
                touch /tmp/inc_wifi_dumped
                dump_incident_snapshot "Gateway Ping & Network Unreachable (Count: $WIFI_FAIL_CNT)"
            fi
            # Soft recovery: Attempt wpa_cli reassociate / reconnect at 30s (6 ticks) and 60s (12 ticks)
            if [ "$WIFI_FAIL_CNT" -eq 6 ] || [ "$WIFI_FAIL_CNT" -eq 12 ]; then
                echo "[WATCHDOG] Network unreachable (tick: $WIFI_FAIL_CNT) -> Soft reconnecting wlan0" >> "$FLASH_LOG_DIR/flight_recorder.log"
                timeout -t 3 wpa_cli -i wlan0 reassociate >/dev/null 2>&1 || timeout -t 3 wpa_cli -i wlan0 reconnect >/dev/null 2>&1
            fi
            # Hard recovery: If network remains unreachable for > 180s (36 ticks), hardware reboot to reset SDIO bus
            if [ "$WIFI_FAIL_CNT" -ge 36 ]; then
                DATE_STR=$(date "+%Y-%m-%d %H:%M:%S" 2>/dev/null || echo "Unknown")
                echo "[WATCHDOG] Network unreachable for >180s -> Hardware rebooting at $DATE_STR" >> "$FLASH_LOG_DIR/crash_watchdog.log"
                sync
                sleep 1
                reboot -f
            fi
        fi
    fi

    # 1.3 UBUS Hardware Switch Driver Health Watchdog
    if timeout -t 2 /bin/ubus call switch state >/dev/null 2>&1; then
        UBUS_FAIL_CNT=0
        rm -f /tmp/inc_ubus_dumped 2>/dev/null
    else
        UBUS_FAIL_CNT=$(( ${UBUS_FAIL_CNT:-0} + 1 ))
        # Pre-Freeze Incident Dump (UBUS Driver failed for 10s)
        if [ "$UBUS_FAIL_CNT" -ge 2 ] && [ ! -f /tmp/inc_ubus_dumped ]; then
            touch /tmp/inc_ubus_dumped
            dump_incident_snapshot "UBUS Switch Driver Unresponsive (Count: $UBUS_FAIL_CNT)"
        fi
        # If UBUS switch driver fails for > 120s (24 ticks), hardware reboot to recover kernel IPC
        if [ "$UBUS_FAIL_CNT" -ge 24 ]; then
            DATE_STR=$(date "+%Y-%m-%d %H:%M:%S" 2>/dev/null || echo "Unknown")
            echo "[WATCHDOG] UBUS Switch Driver dead for >120s -> Hardware rebooting at $DATE_STR" >> "$FLASH_LOG_DIR/crash_watchdog.log"
            sync
            sleep 1
            reboot -f
        fi
    fi

    # 1.4 Background Daemons Keepalive
    if ! pidof ha_daemon >/dev/null 2>&1; then
        nohup /data/scripts/ha_daemon >/tmp/ha_daemon.log 2>&1 &
    fi
    if [ -f /data/scripts/web_telnetd ] && ! pidof web_telnetd >/dev/null 2>&1; then
        nohup /data/scripts/web_telnetd >/tmp/web_telnetd.log 2>&1 &
    fi

    # -------------------------------------------------------------
    # 2. Active High-Watermark Memory Relief & Tmpfs Pruning
    # -------------------------------------------------------------
    CUR_AVAIL_KB=$(awk '/MemAvailable:/ {print $2}' /proc/meminfo 2>/dev/null || echo 20480)
    if [ "$CUR_AVAIL_KB" -lt 14336 ]; then # If available memory drops below 14 MB
        rm -f /tmp/fb_stream.bin /tmp/s1e_ota_latest.tar.gz /tmp/do_ota.sh /tmp/*.b64 /tmp/*.gz /tmp/*.tmp /tmp/bench_* /tmp/upload_* /tmp/index_patched.html 2>/dev/null
        for LF in /tmp/api_access.log /tmp/uilog.txt /tmp/app.log /tmp/ha_daemon.log; do
            if [ -f "$LF" ]; then
                LSZ=$(wc -c < "$LF" 2>/dev/null || echo 0)
                if [ "$LSZ" -gt 32768 ]; then
                    # In-place truncation: NEVER use mv -f, which decouples open file descriptors (e.g. sysservice)
                    tail -n 100 "$LF" > "${LF}.t" 2>/dev/null && cp -f "${LF}.t" "$LF" 2>/dev/null && rm -f "${LF}.t" 2>/dev/null
                fi
            fi
        done
        # Defend against unlinked inode leaks (e.g. sysservice writing to deleted /tmp/uilog.txt)
        for UFD in /proc/[0-9]*/fd/1 /proc/[0-9]*/fd/2; do
            if [ -e "$UFD" ]; then
                UF_TGT=$(readlink "$UFD" 2>/dev/null)
                case "$UF_TGT" in
                    *uilog.txt*deleted*)
                        UFSZ=$(wc -c < "$UFD" 2>/dev/null || echo 0)
                        if [ "$UFSZ" -gt 32768 ]; then
                            : > "$UFD" 2>/dev/null
                        fi
                        ;;
                esac
            fi
        done
        if [ -d /tmp/notify_snaps ]; then
            SNAP_CNT=$(ls -1 /tmp/notify_snaps/*.png 2>/dev/null | wc -l)
            if [ "$SNAP_CNT" -gt 50 ]; then
                ls -1t /tmp/notify_snaps/*.png 2>/dev/null | tail -n +51 | xargs rm -f 2>/dev/null
            fi
        fi
        sync
        echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
    fi

    # -------------------------------------------------------------
    # 3. Flight Recorder Telemetry & Automatic Log Rotation (Every 60s)
    # -------------------------------------------------------------
    LOOP_CNT=$(( (LOOP_CNT + 1) % 12 ))
    if [ "$LOOP_CNT" -eq 0 ]; then
        REC_TIME=$(date "+%Y-%m-%d %H:%M:%S")
        REC_AVAIL=$(awk '/MemAvailable:/ {print int($2/1024)"MB"}' /proc/meminfo 2>/dev/null || echo "?")
        REC_S1E_PID=$(pidof s1e_standalone_app 2>/dev/null)
        REC_S1E_RSS="DOWN"
        if [ -n "$REC_S1E_PID" ]; then
            REC_S1E_RSS=$(awk '/VmRSS:/ {print int($2/1024)"MB"}' /proc/$REC_S1E_PID/status 2>/dev/null || echo "?")
        fi
        REC_HA_PID=$(pidof ha_daemon 2>/dev/null)
        REC_HA_RSS="DOWN"
        if [ -n "$REC_HA_PID" ]; then
            REC_HA_RSS=$(awk '/VmRSS:/ {print int($2/1024)"MB"}' /proc/$REC_HA_PID/status 2>/dev/null || echo "?")
        fi
        REC_SCR="ON"
        if [ -f /tmp/screen_is_off ]; then REC_SCR="OFF"; fi
        REC_WPA=$(timeout -t 2 wpa_cli -i wlan0 status 2>/dev/null | grep '^wpa_state=' | cut -d= -f2 || echo "OFF")
        REC_UBUS="ERR"
        if timeout -t 2 /bin/ubus call switch state >/dev/null 2>&1; then REC_UBUS="OK"; fi
        REC_LOAD=$(awk '{print $1}' /proc/loadavg 2>/dev/null || echo "?")

        echo "$REC_TIME | Scr:$REC_SCR | Avail:$REC_AVAIL | S1E:$REC_S1E_RSS | HA:$REC_HA_RSS | WiFi:$REC_WPA | UBUS:$REC_UBUS | Load:$REC_LOAD" >> "$FLASH_LOG_DIR/flight_recorder.log"

        # Rotate flight recorder if > 128KB
        if [ -f "$FLASH_LOG_DIR/flight_recorder.log" ]; then
            FR_SZ=$(wc -c < "$FLASH_LOG_DIR/flight_recorder.log" 2>/dev/null)
            if [ -n "$FR_SZ" ] && [ "$FR_SZ" -gt 131072 ]; then # > 128KB
                mv -f "$FLASH_LOG_DIR/flight_recorder.log" "$FLASH_LOG_DIR/flight_recorder.log.1" 2>/dev/null
            fi
        fi

        # Rotate transient logs if > 64KB (In-place truncation: NEVER use mv -f)
        for LOGF in /tmp/uilog.txt /tmp/app.log /tmp/ha_daemon.log /tmp/api_access.log /tmp/web_telnetd.log "$FLASH_LOG_DIR/crash_watchdog.log"; do
            if [ -f "$LOGF" ]; then
                SZ=$(wc -c < "$LOGF" 2>/dev/null)
                if [ -n "$SZ" ] && [ "$SZ" -gt 65536 ]; then # > 64KB
                    tail -n 100 "$LOGF" > "${LOGF}.tmp" 2>/dev/null && cp -f "${LOGF}.tmp" "$LOGF" 2>/dev/null && rm -f "${LOGF}.tmp" 2>/dev/null
                fi
            fi
        done

        # Active sysservice uilog open fd watchdog: truncate whenever > 32KB to prevent RAM bloating
        for UFD in /proc/[0-9]*/fd/1 /proc/[0-9]*/fd/2; do
            if [ -e "$UFD" ]; then
                UF_TGT=$(readlink "$UFD" 2>/dev/null)
                case "$UF_TGT" in
                    *uilog.txt*)
                        UFSZ=$(wc -c < "$UFD" 2>/dev/null || echo 0)
                        if [ "$UFSZ" -gt 32768 ]; then
                            : > "$UFD" 2>/dev/null
                        fi
                        ;;
                esac
            fi
        done
    fi
done
