#!/bin/sh
HOST="$1"
PATH_URL="$2"
OUT_FILE="$3"
TIMEOUT="${4:-30}"

if [ -z "$HOST" ] || [ -z "$PATH_URL" ] || [ -z "$OUT_FILE" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') [FETCH] Usage: $0 <host> <path> <outfile> [timeout]"
    exit 1
fi

TMP_OUT="${OUT_FILE}.tmp$$"
rm -f "$TMP_OUT"

do_get() {
    _h="$1"
    _p="$2"
    _to="${3:-10}"
    printf "GET %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: Mozilla/5.0 (S1E-OTA)\r\nConnection: close\r\n\r\n" "$_p" "$_h" | \
        timeout -t "$_to" openssl s_client -4 -servername "${_h}" -connect "${_h}:443" -quiet 2>/dev/null | \
        /data/scripts/http_body_strip > "$TMP_OUT"
    [ -s "$TMP_OUT" ]
}

SUCCESS=0

# If target is raw.githubusercontent.com, try fast CDN first (fastly.jsdelivr.net), then raw.githubusercontent.com
if [ "$HOST" = "raw.githubusercontent.com" ] && echo "$PATH_URL" | grep -q "^/oopuuu/AqaraS1E-Custom-GUI/main/"; then
    JSD_PATH="/gh/oopuuu/AqaraS1E-Custom-GUI@main/${PATH_URL#/oopuuu/AqaraS1E-Custom-GUI/main/}"
    JSD_TO=8
    [ "$TIMEOUT" -gt 20 ] && JSD_TO="$TIMEOUT"
    if do_get "fastly.jsdelivr.net" "$JSD_PATH" "$JSD_TO"; then
        SUCCESS=1
    fi
fi

# If CDN not applicable or failed, try direct host with IPv4 only
if [ "$SUCCESS" -eq 0 ]; then
    if do_get "$HOST" "$PATH_URL" "$TIMEOUT"; then
        SUCCESS=1
    fi
fi

if [ "$SUCCESS" -eq 1 ] && [ -s "$TMP_OUT" ]; then
    mv -f "$TMP_OUT" "$OUT_FILE"
    exit 0
else
    rm -f "$TMP_OUT"
    exit 1
fi
